/** Bitmap decorators. */
package com.stanfy.images.decorator;
