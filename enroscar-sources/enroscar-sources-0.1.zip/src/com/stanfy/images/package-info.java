/** Images operations. */
package com.stanfy.images;
