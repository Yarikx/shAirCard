package com.stanfy;

/**
 * @author Roman Mazur - Stanfy (http://www.stanfy.com)
 */
public interface Destroyable {

  /** Destroy. */
  void destroy();

}
