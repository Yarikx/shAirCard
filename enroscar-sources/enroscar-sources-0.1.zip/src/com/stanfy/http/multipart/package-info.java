/** Multipart support for Android HTTP client. */
package com.stanfy.http.multipart;
