package com.stanfy.utils;

/**
 * Eclair utilities (API level 7).
 * @author Roman Mazur - Stanfy (http://www.stanfy.com)
 */
public class EclairUtils extends LowestSDKDependentUtils {

}
