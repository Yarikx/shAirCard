/** Utilities. */
package com.stanfy.utils;
