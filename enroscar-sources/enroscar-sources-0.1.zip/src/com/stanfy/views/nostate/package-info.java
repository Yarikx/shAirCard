/** View groups that do not pass their states to children. */
package com.stanfy.views.nostate;
