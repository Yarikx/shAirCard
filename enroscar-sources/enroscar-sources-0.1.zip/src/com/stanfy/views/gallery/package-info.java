/** Gallery implementations. */
package com.stanfy.views.gallery;
