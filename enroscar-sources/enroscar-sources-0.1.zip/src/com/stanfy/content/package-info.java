/** Content related classes. */
package com.stanfy.content;
