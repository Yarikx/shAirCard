/** Some useful activities. */
package com.stanfy.app.activities;
