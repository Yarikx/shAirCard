/** Fragments / activities to work with fetchable list view. */
package com.stanfy.app.fragments.list;
