/** Some useful fragments. */
package com.stanfy.app.fragments;
