/** Application base classes. */
package com.stanfy.app;
