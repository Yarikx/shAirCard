/** Services base classes. */
package com.stanfy.app.service;
