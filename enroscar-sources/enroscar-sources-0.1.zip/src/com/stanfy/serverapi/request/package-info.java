/** Classes for communicating with server REST API. */
package com.stanfy.serverapi.request;
