package com.stanfy.serverapi.response.xml;

/**
 * List processor.
 * Just a marker class.
 * @author Olexandr Tereshchuk - Stanfy (http://www.stanfy.com)
 */
public abstract class BaseListProcessor extends ElementProcessor {

}
