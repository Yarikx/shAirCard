/** Classes to work with server-size API response. */
package com.stanfy.serverapi.response;
