/** Classes to work with server-size API. */
package com.stanfy.serverapi;
