/** Classes to work with local cache of API responses. */
package com.stanfy.serverapi.cache;
